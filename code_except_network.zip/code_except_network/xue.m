clear all; clc;
load('influence_data.mat')

%% artist_info_list
follower_id = str2num(char(follower_id));
influencer_id = str2num(char(influencer_id));
artist_list = unique([follower_id, influencer_id]);

follower_active_start = str2num(char(follower_active_start));
influencer_active_start = str2num(char(influencer_active_start));
active_start_list = unique([follower_active_start, influencer_active_start]);

main_genre_list = unique([follower_main_genre(:)', influencer_main_genre(:)']);
% main_genre_list = char(main_genre_list);
% follower_main_genre = char(follower_main_genre);
% influencer_main_genre = char(influencer_main_genre);
follower_main_genre_coding = zeros(length(follower_main_genre), 1);
influencer_main_genre_coding = zeros(length(influencer_main_genre), 1);
for ii = 1:length(main_genre_list)
    Index = strfind(follower_main_genre, main_genre_list(ii));
    Index_empty = cellfun(@isempty, Index);
    Index(Index_empty) = {0};
    Index = cell2mat(Index);
    Index = Index == 1;
    follower_main_genre_coding(Index) = ii;
    
    Index = strfind(influencer_main_genre, main_genre_list(ii));
    Index_empty = cellfun(@isempty, Index);
    Index(Index_empty) = {0};
    Index = cell2mat(Index);
    Index = Index == 1;
    influencer_main_genre_coding(Index) = ii;
end

artist_info_list = [follower_id, follower_active_start, follower_main_genre_coding;
    influencer_id, influencer_active_start, influencer_main_genre_coding];
artist_info_list = unique(artist_info_list, 'rows');
save artist_info_list artist_info_list