clear;clc;

feature('DefaultCharacterSet', 'UTF8');
influence_data = importdata('influence_data.csv');
data_by_artist = importdata('data_by_artist.csv');
load fullmusicdata

influence_all_artist_1 = influence_data.textdata(:,1);
influence_all_artist_1(1) = [];
influence_all_artist_1 = str2num(char(influence_all_artist_1));

influence_all_artist_1_genres = influence_data.textdata(:,3);
influence_all_artist_1_genres(1) = [];

influence_all_artist_2 = influence_data.textdata(:,5);
influence_all_artist_2(1) = [];
influence_all_artist_2 = str2num(char(influence_all_artist_2));

influence_all_artist_2_genres = influence_data.textdata(:,7);
influence_all_artist_2_genres(1) = [];


influence_all_artist = [influence_all_artist_1 ; influence_all_artist_2];
influence_all_artist_genres = [influence_all_artist_1_genres;influence_all_artist_1_genres];

unique_influence_all_artist = unique(influence_all_artist);
unique_genres  = unique(influence_all_artist_genres);

danceability = zeros(1,20);
energy = zeros(1,20);
valence = zeros(1,20);
tempo = zeros(1,20);
loudness = zeros(1,20);
mode = zeros(1,20);
key = zeros(1,20);
acousticness = zeros(1,20);
instrumentalness = zeros(1,20);
liveness = zeros(1,20);
speechiness = zeros(1,20);
duration_ms = zeros(1,20);
popularity = zeros(1,20);

count = zeros(1,20);

for i = 1:98340
    temp = str2num(fullmusicdata(i,2));
    index = find(influence_all_artist == temp(1)); 
    if isempty(index)
        continue  
    else
        genres = cell2mat(influence_all_artist_genres(index(1)));
        id = ismember(unique_genres,genres);
        genres_index = find(id == 1);

        danceability(genres_index) = danceability(genres_index) + str2num(fullmusicdata(i,3));
        energy(genres_index) = energy(genres_index) + str2num(fullmusicdata(i,4));
        valence(genres_index) = valence(genres_index) + str2num(fullmusicdata(i,5));
        tempo(genres_index) = tempo(genres_index) + str2num(fullmusicdata(i,6));
        loudness(genres_index) = loudness(genres_index) + str2num(fullmusicdata(i,7));
        mode(genres_index) = mode(genres_index) + str2num(fullmusicdata(i,8));
        key(genres_index) = key(genres_index) + str2num(fullmusicdata(i,9));
        acousticness(genres_index) = acousticness(genres_index) + str2num(fullmusicdata(i,10));
        instrumentalness(genres_index) = instrumentalness(genres_index) + str2num(fullmusicdata(i,11));
        liveness(genres_index) = liveness(genres_index) + str2num(fullmusicdata(i,12));
        speechiness(genres_index) = speechiness(genres_index) + str2num(fullmusicdata(i,13));
        duration_ms(genres_index) = duration_ms(genres_index) + str2num(fullmusicdata(i,15));
        popularity(genres_index) = popularity(genres_index) + str2num(fullmusicdata(i,16));
        count(genres_index) = count(genres_index) + 1;
    end   
end

danceability_ave = danceability./count;
energy_ave = energy./count;
valence_ave = valence./count;
tempo_ave = tempo./count;
loudness_ave = loudness./count;
mode_ave = mode./count;
key_ave = key./count;
acousticness_ave = acousticness./count;
instrumentalness_ave = instrumentalness./count;
liveness_ave = liveness./count;
speechiness_ave = speechiness./count;
duration_ms_ave = duration_ms./count;
popularity_ave = popularity./count;

whole = [danceability_ave;energy_ave;valence_ave;tempo_ave;loudness_ave;mode_ave;key_ave;acousticness_ave;instrumentalness_ave;liveness_ave;speechiness_ave;duration_ms_ave;popularity_ave]';











