Here's all the code except for the network.
Some variables may not be stored, please run the code and save the variables manually.

At first:
xue.m
genre.m
read.m

Question2:
choose_feature.m
corr_matrix_choose_feature.m
t_test.m

Question3:
genre_simlarity.m
genre_year.m
plot_genre_year.m

Question4:
question_4.m
question4_2.m

Question5:
year.m

Question6:
question6.m
genre_simlarity_year.m