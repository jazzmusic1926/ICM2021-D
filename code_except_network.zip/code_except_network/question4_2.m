clear;clc;

feature('DefaultCharacterSet', 'UTF8');
influence_data = importdata('influence_data.csv');
data_by_artist = importdata('data_by_artist.csv');
load fullmusicdata

influence_all_artist_1 = influence_data.textdata(:,1);
influence_all_artist_1(1) = [];
influence_all_artist_1 = str2num(char(influence_all_artist_1));

influence_all_artist_2 = influence_data.textdata(:,5);
influence_all_artist_2(1) = [];
influence_all_artist_2 = str2num(char(influence_all_artist_2));

influence_all_artist = [influence_all_artist_1 influence_all_artist_2];

artist_matrix = data_by_artist.data(:,[1,2,3,4,6,9,10,12,13]);

artist_matrix_normalizing = artist_matrix(:,2:9);

for m = 1:7
    artist_matrix_normalizing(:,m) = zscore(artist_matrix(:,m));
end

characteristic_1 = zeros(42770,2);
characteristic_2 = zeros(42770,2);
characteristic_3 = zeros(42770,2);
characteristic_4 = zeros(42770,2);
characteristic_5 = zeros(42770,2);
characteristic_6 = zeros(42770,2);
characteristic_7 = zeros(42770,2);
characteristic_8 = zeros(42770,2);

for i = 1:42770
    influencer_index = find(artist_matrix(:,1) == influence_all_artist(i,1));
    follower_index = find(artist_matrix(:,1) == influence_all_artist(i,2));
    if(isempty(influencer_index) || isempty(follower_index))
        
    else
        characteristic_1(i,1) = artist_matrix_normalizing(influencer_index,1);
        characteristic_1(i,2) = artist_matrix_normalizing(follower_index,1);
        
        characteristic_2(i,1) = artist_matrix_normalizing(influencer_index,2);
        characteristic_2(i,2) = artist_matrix_normalizing(follower_index,2);
        
        characteristic_3(i,1) = artist_matrix_normalizing(influencer_index,3);
        characteristic_3(i,2) = artist_matrix_normalizing(follower_index,3);
        
        characteristic_4(i,1) = artist_matrix_normalizing(influencer_index,4);
        characteristic_4(i,2) = artist_matrix_normalizing(follower_index,4);
        
        characteristic_5(i,1) = artist_matrix_normalizing(influencer_index,5);
        characteristic_5(i,2) = artist_matrix_normalizing(follower_index,5);
        
        characteristic_6(i,1) = artist_matrix_normalizing(influencer_index,6);
        characteristic_6(i,2) = artist_matrix_normalizing(follower_index,6);
        
        characteristic_7(i,1) = artist_matrix_normalizing(influencer_index,7);
        characteristic_7(i,2) = artist_matrix_normalizing(follower_index,7);
        
        characteristic_8(i,1) = artist_matrix_normalizing(influencer_index,8);
        characteristic_8(i,2) = artist_matrix_normalizing(follower_index,8);
    end       
end
index_0_1 = find(characteristic_1(:,1) == 0 & characteristic_1(:,2) == 0);
characteristic_1(index_0_1,:) = [];

index_0_2 = find(characteristic_2(:,1) == 0 & characteristic_2(:,2) == 0);
characteristic_2(index_0_2,:) = [];

index_0_3 = find(characteristic_3(:,1) == 0 & characteristic_3(:,2) == 0);
characteristic_3(index_0_3,:) = [];

index_0_4 = find(characteristic_4(:,1) == 0 & characteristic_4(:,2) == 0);
characteristic_4(index_0_4,:) = [];

index_0_5 = find(characteristic_5(:,1) == 0 & characteristic_5(:,2) == 0);
characteristic_5(index_0_5,:) = [];

index_0_6 = find(characteristic_6(:,1) == 0 & characteristic_6(:,2) == 0);
characteristic_6(index_0_6,:) = [];

index_0_7 = find(characteristic_7(:,1) == 0 & characteristic_7(:,2) == 0);
characteristic_7(index_0_7,:) = [];

index_0_8 = find(characteristic_8(:,1) == 0 & characteristic_8(:,2) == 0);
characteristic_8(index_0_8,:) = [];

corr_characteristic = zeros(8,1);
temp_corr_1 = corrcoef(characteristic_1(:,1),characteristic_1(:,2));
corr_characteristic(1) = temp_corr_1(2);

temp_corr_2 = corrcoef(characteristic_2(:,1),characteristic_2(:,2));
corr_characteristic(2) = temp_corr_2(2);

temp_corr_3 = corrcoef(characteristic_3(:,1),characteristic_3(:,2));
corr_characteristic(3) = temp_corr_3(2);

temp_corr_4 = corrcoef(characteristic_4(:,1),characteristic_4(:,2));
corr_characteristic(4) = temp_corr_4(2);

temp_corr_5 = corrcoef(characteristic_5(:,1),characteristic_5(:,2));
corr_characteristic(5) = temp_corr_5(2);

temp_corr_6 = corrcoef(characteristic_6(:,1),characteristic_6(:,2));
corr_characteristic(6) = temp_corr_6(2);

temp_corr_7 = corrcoef(characteristic_7(:,1),characteristic_7(:,2));
corr_characteristic(7) = temp_corr_7(2);

temp_corr_8 = corrcoef(characteristic_8(:,1),characteristic_8(:,2));
corr_characteristic(8) = temp_corr_8(2);

temp_1 = (1 + corr_characteristic) ./ (1 - corr_characteristic);
corr_characteristic_fisherz = 0.5 * log(temp_1);


corr_p = zeros(8,8);
n = 42572;
for t = 1:8
    for y = 1:8
        if(t == y)
            break;
        else
            z = (corr_characteristic_fisherz(t)-corr_characteristic_fisherz(y))/sqrt(1/(n-3)+1/(n-3));
            z = -abs(z);
            corr_p(t,y) = normcdf(z) * 2;
        end
    end
end










