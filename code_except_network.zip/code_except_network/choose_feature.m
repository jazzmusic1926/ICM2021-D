% You need download the randomforest-matlab package frist
% http://code.google.com/archive/p/randomforest-matlab/

clear;clc;
feature('DefaultCharacterSet', 'UTF8');
data_by_artist = importdata('data_by_artist.csv');
load artist_info_list

whole_artist = data_by_artist.data;
whole_artist(:,16) = zeros(5854,1);

for i = 1:5854
    index = find(artist_info_list(:,1) == whole_artist(i,1));
    if isempty(index)
        continue  
    else
    genres = artist_info_list(index,3);
    whole_artist(i,16) = genres;
    end
end

a = find(whole_artist(:,16) == 0);
whole_artist(a,:) = [];

% random forest
% You need download the randomforest-matlab package frist
% http://code.google.com/archive/p/randomforest-matlab/
data = whole_artist;
data(:,15) = [];
data(:,14) = [];
data(:,1) = [];

b = randperm(5602);
Train = data(b(1:4602),:);
Test = data(b(4602:end),:);

P_train = Train(:,1:12);
T_train = Train(:,13);

P_test = Test(:,1:12);
T_test = Test(:,13);

clear extra_options
extra_options.importance = 1;

model = classRF_train(P_train,T_train,500,4,extra_options);
Y_hat = classRF_predict(P_test,model); 
err_rate = length(find(Y_hat~=T_test));

figure('Name','Importance Plots')
figure(1)
X = categorical({'danceability' 'energy' 'valence' 'tempo' 'loudness' 'mode' 'key' 'acousticness' 'instrumentalness' 'liveness' 'speechiness' 'duration'});
X = reordercats(X,{'danceability' 'energy' 'valence' 'tempo' 'loudness' 'mode' 'key' 'acousticness' 'instrumentalness' 'liveness' 'speechiness' 'duration'});
bar(X,model.importance(:,end-1));
xlabel('feature');ylabel('magnitude');
    




