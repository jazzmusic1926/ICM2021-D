clear;clc;close all;
feature('DefaultCharacterSet', 'UTF8');

load genre_year

% for i = 1:14
%     figure(i)
%     plot(1921:2020,whole_year_genres{14}(:,i));
% end
data_by_year = importdata('data_by_year.csv');
year_matrix = data_by_year.data(:,[2,3,4,6,9,10,12,13]);

year_matrix_normalizing = zeros(100,8);
for k = 1:8
    year_matrix_normalizing(:,k) = zscore(year_matrix(:,k));
end

corr_sum = zeros(1,99);
for i = 1:99
    x = year_matrix_normalizing(i,1:8);
    y = year_matrix_normalizing(i+1,1:8);
    
    corr_matrix = corrcoef(x,y);
    corr_sum(i) = corr_matrix(2);
end
figure(1)
plot(1922:2020,corr_sum,'LineStyle','-','Marker','o','Color','r','MarkerSize',2);
xlabel('Year','FontSize',18)
ylabel('Correlation','FontSize',18)
set(gca,'color','none');

figure(2)
for i = 1:7
    plot(1921:1930,whole_year_genres{i}(1:10,14),'LineStyle','-','Marker','o','MarkerSize',2);
    hold on
end

for j = 8:14
    plot(1921:1930,whole_year_genres{j}(1:10,14),'LineStyle','--','Marker','+','MarkerSize',2);
    hold on
end

for k = 15:20
    plot(1921:1930,whole_year_genres{k}(1:10,14),'LineStyle',':','Marker','x','MarkerSize',2);
    hold on
end
legend('Avant-Garde','Blues','Childrens','Classical','Comedy/Spoken','Country','Easy Listening','Electronic','Folk','International','Jazz','Latin','New Age','Pop/Rock','R&B','Reggae','Religious','Stage & Screen','Unknown','Vocal','FontSize',12)
xlabel('Year','FontSize',18)
ylabel('Number of music','FontSize',18)
set(gca,'color','none');

figure(3)
for i = 1:7
    plot(1931:1960,whole_year_genres{i}(11:40,14),'LineStyle','-','Marker','o','MarkerSize',2);
    hold on
end

for j = 8:14
    plot(1931:1960,whole_year_genres{j}(11:40,14),'LineStyle','--','Marker','+','MarkerSize',2);
    hold on
end

for k = 15:20
    plot(1931:1960,whole_year_genres{k}(11:40,14),'LineStyle',':','Marker','x','MarkerSize',2);
    hold on
end

legend('Avant-Garde','Blues','Childrens','Classical','Comedy/Spoken','Country','Easy Listening','Electronic','Folk','International','Jazz','Latin','New Age','Pop/Rock','R&B','Reggae','Religious','Stage & Screen','Unknown','Vocal','FontSize',12)
xlabel('Year','FontSize',18)
ylabel('Number of music','FontSize',18)
set(gca,'color','none');

figure(4)
for i = 1:7
    plot(1961:1990,whole_year_genres{i}(41:70,14),'LineStyle','-','Marker','o','MarkerSize',2);
    hold on
end

for j =8:14
    plot(1961:1990,whole_year_genres{j}(41:70,14),'LineStyle','--','Marker','+','MarkerSize',2);
    hold on
end

for k = 15:20
    plot(1961:1990,whole_year_genres{k}(41:70,14),'LineStyle',':','Marker','x','MarkerSize',2);
    hold on
end
legend('Avant-Garde','Blues','Childrens','Classical','Comedy/Spoken','Country','Easy Listening','Electronic','Folk','International','Jazz','Latin','New Age','Pop/Rock','R&B','Reggae','Religious','Stage & Screen','Unknown','Vocal','FontSize',12)
xlabel('Year','FontSize',18)
ylabel('Number of music','FontSize',18)
set(gca,'color','none');


figure(5)
for i = 1:7
    plot(1991:2020,whole_year_genres{i}(71:100,14),'LineStyle','-','Marker','o','MarkerSize',2);
    hold on
end

for j = 8:14
    plot(1991:2020,whole_year_genres{j}(71:100,14),'LineStyle','--','Marker','+','MarkerSize',2);
    hold on
end

for k = 15:20
    plot(1991:2020,whole_year_genres{k}(71:100,14),'LineStyle',':','Marker','x','MarkerSize',2);
    hold on
end
legend('Avant-Garde','Blues','Childrens','Classical','Comedy/Spoken','Country','Easy Listening','Electronic','Folk','International','Jazz','Latin','New Age','Pop/Rock','R&B','Reggae','Religious','Stage & Screen','Unknown','Vocal','FontSize',12)
xlabel('Year','FontSize',18)
ylabel('Number of music','FontSize',18)
set(gca,'color','none');