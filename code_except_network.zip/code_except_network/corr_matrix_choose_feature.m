clear;clc;
feature('DefaultCharacterSet', 'UTF8');
data_by_artist = importdata('data_by_artist.csv');
load artist_info_list
artist_matrix = data_by_artist.data(:,[1,2,3,4,6,9,10,12,13]);

for q = 1:5603
    switch(artist_info_list(q,3))
        case 14
            artist_info_list(q,4) = 1;
        case 15
            artist_info_list(q,4) = 2;
        case 11
            artist_info_list(q,4) = 3;
        case 6
            artist_info_list(q,4) = 4;
        case 12
            artist_info_list(q,4) = 5;
        case 8
            artist_info_list(q,4) = 6;
        case 20
            artist_info_list(q,4) = 7;
        case 16
            artist_info_list(q,4) = 8;
        case 2
            artist_info_list(q,4) = 9;
        case 9
            artist_info_list(q,4) = 10;
        case 17
            artist_info_list(q,4) = 11;
        case 10
            artist_info_list(q,4) = 12;
        case 18
            artist_info_list(q,4) = 13;
        case 5
            artist_info_list(q,4) = 14;
        case 13
            artist_info_list(q,4) = 15;
        case 4
            artist_info_list(q,4) = 16;
        case 7
            artist_info_list(q,4) = 17;
        case 1
            artist_info_list(q,4) = 18;
        case 3
            artist_info_list(q,4) = 19;
        case 19
            artist_info_list(q,4) = 20;
    end      
end
a = sortrows(artist_info_list,4);
a(:,4) = [];


number = zeros(1,20);
b = [1:20 ; number]';
bb = sortrows(b,2,'descend');

for i = 1:20
    number(i) = size(find(a(:,3) == i),1);
end

artist_matirx_have_genre = zeros(5603,8);

for k = 1:5603
    index = find(artist_matrix(:,1) == a(k,1));
    if(isempty(index))
        continue        
    else    
        artist_matirx_have_genre(k,:) = artist_matrix(index,2:9);
    end
end

artist_matrix_normalizing = zeros(5603,8);
for m = 1:7
    artist_matrix_normalizing(:,m) = zscore(artist_matirx_have_genre(:,m));
end

corr = corrcoef(artist_matrix_normalizing');
imagesc(corr);
save corr corr