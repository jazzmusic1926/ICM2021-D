clear;clc;

feature('DefaultCharacterSet', 'UTF8');
influence_data = importdata('influence_data.csv');
data_by_artist = importdata('data_by_artist.csv');
load fullmusicdata

influence_all_artist_1 = influence_data.textdata(:,1);
influence_all_artist_1(1) = [];
influence_all_artist_1 = str2num(char(influence_all_artist_1));

influence_all_artist_1_genres = influence_data.textdata(:,3);
influence_all_artist_1_genres(1) = [];

influence_all_artist_2 = influence_data.textdata(:,5);
influence_all_artist_2(1) = [];
influence_all_artist_2 = str2num(char(influence_all_artist_2));

influence_all_artist_2_genres = influence_data.textdata(:,7);
influence_all_artist_2_genres(1) = [];


influence_all_artist = [influence_all_artist_1 ; influence_all_artist_2];
influence_all_artist_genres = [influence_all_artist_1_genres;influence_all_artist_1_genres];

unique_influence_all_artist = unique(influence_all_artist);
unique_genres  = unique(influence_all_artist_genres);

whole_year_genres = cell(20,1);
count_year_genres = cell(20,1);
for p = 1:20
    whole_year_genres{p} = zeros(100,14);
    count_year_genres{p} = zeros(100,1);
end

for i = 1:98340
    temp = str2num(fullmusicdata(i,2));
    index = find(influence_all_artist == temp(1)); 
    if isempty(index)
        continue  
    else
        year = str2num(fullmusicdata(i,17)) - 1920;   
        genres = cell2mat(influence_all_artist_genres(index(1)));
        id = ismember(unique_genres,genres);
        genres_index = find(id == 1);
        
        whole_year_genres{genres_index}(year,1) = whole_year_genres{genres_index}(year,1) + str2num(fullmusicdata(i,3));
        whole_year_genres{genres_index}(year,2) = whole_year_genres{genres_index}(year,2) + str2num(fullmusicdata(i,4));
        whole_year_genres{genres_index}(year,3) = whole_year_genres{genres_index}(year,3) + str2num(fullmusicdata(i,5));
        whole_year_genres{genres_index}(year,4) = whole_year_genres{genres_index}(year,4) + str2num(fullmusicdata(i,6));
        whole_year_genres{genres_index}(year,5) = whole_year_genres{genres_index}(year,5) + str2num(fullmusicdata(i,7));
        whole_year_genres{genres_index}(year,6) = whole_year_genres{genres_index}(year,6) + str2num(fullmusicdata(i,8));
        whole_year_genres{genres_index}(year,7) = whole_year_genres{genres_index}(year,7) + str2num(fullmusicdata(i,9));
        whole_year_genres{genres_index}(year,8) = whole_year_genres{genres_index}(year,8) + str2num(fullmusicdata(i,10));
        whole_year_genres{genres_index}(year,9) = whole_year_genres{genres_index}(year,9) + str2num(fullmusicdata(i,11));
        whole_year_genres{genres_index}(year,10) = whole_year_genres{genres_index}(year,10) + str2num(fullmusicdata(i,12));
        whole_year_genres{genres_index}(year,11) = whole_year_genres{genres_index}(year,11) + str2num(fullmusicdata(i,13));
        whole_year_genres{genres_index}(year,12) = whole_year_genres{genres_index}(year,12) + str2num(fullmusicdata(i,15));
        whole_year_genres{genres_index}(year,13) = whole_year_genres{genres_index}(year,13) + str2num(fullmusicdata(i,16));
        whole_year_genres{genres_index}(year,14) = whole_year_genres{genres_index}(year,14) + 1;
        
        count_year_genres{genres_index}(year) = count_year_genres{genres_index}(year) + 1;
    end   
end

for j = 1:20
    for n = 1:100
    whole_year_genres{j}(n,1:13) = whole_year_genres{j}(n,1:13)./count_year_genres{j}(n);
    end
end
save genre_year

