clear;clc;

feature('DefaultCharacterSet', 'UTF8');
influence_data = importdata('influence_data.csv');
data_by_artist = importdata('data_by_artist.csv');
load fullmusicdata

influence_all_artist_1 = influence_data.textdata(:,1);
influence_all_artist_1(1) = [];
influence_all_artist_1 = str2num(char(influence_all_artist_1));

influence_all_artist_2 = influence_data.textdata(:,5);
influence_all_artist_2(1) = [];
influence_all_artist_2 = str2num(char(influence_all_artist_2));

artist_matrix = data_by_artist.data(:,[1,2,3,4,6,9,10,12,13]);


for m = 1:8
    artist_matrix_normalizing(:,m) = zscore(artist_matrix(:,m));
end


influence_all_artist = [influence_all_artist_1 influence_all_artist_2];

corr_influencer_follower = [];

for i = 1:42770
    influencer_index = find(artist_matrix(:,1) == influence_all_artist(i,1));
    follower_index = find(artist_matrix(:,1) == influence_all_artist(i,2));
    if(isempty(influencer_index) || isempty(follower_index))
        continue
    else
        influencer = artist_matrix_normalizing(influencer_index,:);
        follower = artist_matrix_normalizing(follower_index,:);
        corr_temp = corrcoef(influencer,follower);
        corr_influencer_follower = [corr_influencer_follower corr_temp(2)];
    end
end

corr = corrcoef(artist_matrix_normalizing');
corr_tril = tril(corr);

k = 0;

for i = 1:5854
    for j = 1:5854
        if(i == j)
            break     
        end
        i_id = artist_matrix(i,1);
        j_id = artist_matrix(j,1);
        temp1 = find(influence_all_artist(:,1) == i_id & influence_all_artist(:,2) == j_id);
        temp2 = find(influence_all_artist(:,2) == i_id & influence_all_artist(:,1) == j_id);
        if(isempty(temp1) && isempty(temp2))
          
        else
            k = k + 1;
            corr_tril(i,j) = -100;
        end
        
    end
end

corr_not_influencer_follower = reshape(corr_tril,1,5854 * 5854);
index_influencer = find(corr_not_influencer_follower == -100);
corr_not_influencer_follower(index_influencer) = [];
index_0 = find(corr_not_influencer_follower == 0);
corr_not_influencer_follower(index_0) = [];

%%
index_1 = find(corr_not_influencer_follower == 1);
corr_not_influencer_follower(index_1) = [];

temp_1 = (1 + corr_influencer_follower) ./ (1 - corr_influencer_follower);
corr_influencer_follower_fisherz = 0.5 * log(temp_1);

temp_2 = (1 + corr_not_influencer_follower) ./ (1 - corr_not_influencer_follower);
corr_not_influencer_follower_fisherz = 0.5 * log(temp_2);

mean_influencer_follower = mean(corr_influencer_follower_fisherz);
mean_not_influencer_follower = mean(corr_not_influencer_follower_fisherz);
std_influencer_follower = std(corr_influencer_follower_fisherz);
std_not_influencer_follower = std(corr_not_influencer_follower_fisherz);

figure(1)
histogram(corr_influencer_follower_fisherz)

figure(2)
histogram(corr_not_influencer_follower_fisherz)

[h,p,ci]=ttest2(corr_influencer_follower_fisherz,corr_not_influencer_follower_fisherz);

