clear;clc;
feature('DefaultCharacterSet', 'UTF8');

load corr_feature_8
count = [2808 677 406 403 229 208 162 141 101 95 89 81 50 46 38 28 23 11 4 3];

corr_same_genre = cell(20,1);
corr_different = cell(20,1);
get_row = ones(20,1);
for i = 1:20
    get_row(i+1) = get_row(i) + count(i);
    corr_same_genre{i} = corr(get_row(i):(get_row(i+1)-1),get_row(i):(get_row(i+1)-1));
    corr_different_temp = corr(get_row(i):(get_row(i+1)-1),:);
    corr_different_temp(:,get_row(i):(get_row(i+1)-1)) = [];
    corr_different{i} = corr_different_temp;
end

corr_same_genre_all_matrix = [];
for j = 1:20
    size_ = size(corr_same_genre{j});
    temp_matrix = reshape(corr_same_genre{j},1,size_(1) * size_(2));
    corr_same_genre_all_matrix = [corr_same_genre_all_matrix temp_matrix];
end

corr_different_genre_all_matrix = [];
for m = 1:20
    size_different = size(corr_different{m});
    temp_matrix_different = reshape(corr_different{m},1,size_different(1) * size_different(2));
    corr_different_genre_all_matrix = [corr_different_genre_all_matrix temp_matrix_different];
end

a = find(corr_same_genre_all_matrix == 1);
b = find(corr_different_genre_all_matrix == 1);

corr_same_genre_all_matrix(a) = [];
corr_different_genre_all_matrix(b) = [];

temp_1 = (1 + corr_same_genre_all_matrix) ./ (1 - corr_same_genre_all_matrix);
corr_same_genre_all_matrix_fisherz = 0.5 * log(temp_1);

temp_2 = (1 + corr_different_genre_all_matrix) ./ (1 - corr_different_genre_all_matrix);
corr_different_genre_all_matrix_fisherz = 0.5 * log(temp_2);

mean_same = mean(corr_same_genre_all_matrix_fisherz);
mean_different = mean(corr_different_genre_all_matrix_fisherz);
std_same = std(corr_same_genre_all_matrix_fisherz);
std_different = std(corr_different_genre_all_matrix_fisherz);

figure(1)
histogram(corr_same_genre_all_matrix_fisherz)

figure(2)
histogram(corr_different_genre_all_matrix_fisherz)


[h,p,ci]=ttest2(corr_same_genre_all_matrix_fisherz,corr_different_genre_all_matrix_fisherz);
realmin('double')

mean_genres = zeros(20,1);
std_genres = zeros(20,1);
for z = 1:20
    corr_vector = corr_same_genre{z}(:);
    index_1 = find(corr_vector == 1);
    corr_vector(index_1) = [];
    mean_genres(z) = mean(corr_vector);
    std_genres(z) = std(corr_vector);
end
