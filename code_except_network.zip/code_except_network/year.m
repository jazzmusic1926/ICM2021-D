clear;clc;close all;
feature('DefaultCharacterSet', 'UTF8');
data_by_year = importdata('data_by_year.csv');
year_matrix = data_by_year.data(:,[2,3,4,6,9,10,12,13]);

year_matrix_normalizing = zeros(100,8);
for k = 1:8
    year_matrix_normalizing(:,k) = zscore(year_matrix(:,k));
end

corr_sum = zeros(1,99);
for i = 1:99
    x = year_matrix_normalizing(i,1:8);
    y = year_matrix_normalizing(i+1,1:8);
    
    corr_matrix = corrcoef(x,y);
    corr_sum(i) = corr_matrix(2);
end
plot(1922:2020,corr_sum)
