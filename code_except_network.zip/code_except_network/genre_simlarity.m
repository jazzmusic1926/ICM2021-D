clear;clc;close all;
feature('DefaultCharacterSet', 'UTF8');
load whole
whole_feature = whole(:,[1,2,3,5,8,9,11,12]);

for k = 1:8
    whole_feature_normalizing(:,k) = zscore(whole_feature(:,k));
end

corr_genre = corrcoef(whole_feature_normalizing');

xvalues = {'Avant-Garde','Blues','Childrens','Classical','Comedy/Spoken','Country','Easy Listening','Electronic','Folk','International','Jazz','Latin','New Age','Pop/Rock','R&B','Reggae','Religious','Stage & Screen','Unknown','Vocal'};
yvalues = {'Avant-Garde','Blues','Childrens','Classical','Comedy/Spoken','Country','Easy Listening','Electronic','Folk','International','Jazz','Latin','New Age','Pop/Rock','R&B','Reggae','Religious','Stage & Screen','Unknown','Vocal'};

h = heatmap(xvalues,yvalues,corr_genre,'FontSize',18);
colormap(jet)