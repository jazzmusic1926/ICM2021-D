clear;clc;close all;
feature('DefaultCharacterSet', 'UTF8');

influence_data = importdata('influence_data.csv');
data_by_artist = importdata('data_by_artist.csv');
load fullmusicdata

influence_all_artist_1 = influence_data.textdata(:,1);
influence_all_artist_1(1) = [];
influence_all_artist_1 = str2num(char(influence_all_artist_1));

influence_all_artist_1_genres = influence_data.textdata(:,3);
influence_all_artist_1_genres(1) = [];

influence_all_artist_2 = influence_data.textdata(:,5);
influence_all_artist_2(1) = [];
influence_all_artist_2 = str2num(char(influence_all_artist_2));

influence_all_artist_2_genres = influence_data.textdata(:,7);
influence_all_artist_2_genres(1) = [];


influence_all_artist = [influence_all_artist_1 ; influence_all_artist_2];
influence_all_artist_genres = [influence_all_artist_1_genres;influence_all_artist_1_genres];

unique_influence_all_artist = unique(influence_all_artist);
unique_genres  = unique(influence_all_artist_genres);

whole_year_genres_per_10 = cell(20,1);
count_year_genres = cell(20,1);
for p = 1:20
    whole_year_genres_per_10{p} = zeros(10,14);
    count_year_genres{p} = zeros(10,1);
end

for i = 1:98340
    temp = str2num(fullmusicdata(i,2));
    index = find(influence_all_artist == temp(1)); 
    if isempty(index)
        continue  
    else
        year = str2num(fullmusicdata(i,17)) - 1920;
        year_per_10 = ceil(year/10);
        genres = cell2mat(influence_all_artist_genres(index(1)));
        id = ismember(unique_genres,genres);
        genres_index = find(id == 1);
        
        whole_year_genres_per_10{genres_index}(year_per_10,1) = whole_year_genres_per_10{genres_index}(year_per_10,1) + str2num(fullmusicdata(i,3));
        whole_year_genres_per_10{genres_index}(year_per_10,2) = whole_year_genres_per_10{genres_index}(year_per_10,2) + str2num(fullmusicdata(i,4));
        whole_year_genres_per_10{genres_index}(year_per_10,3) = whole_year_genres_per_10{genres_index}(year_per_10,3) + str2num(fullmusicdata(i,5));
        whole_year_genres_per_10{genres_index}(year_per_10,4) = whole_year_genres_per_10{genres_index}(year_per_10,4) + str2num(fullmusicdata(i,6));
        whole_year_genres_per_10{genres_index}(year_per_10,5) = whole_year_genres_per_10{genres_index}(year_per_10,5) + str2num(fullmusicdata(i,7));
        whole_year_genres_per_10{genres_index}(year_per_10,6) = whole_year_genres_per_10{genres_index}(year_per_10,6) + str2num(fullmusicdata(i,8));
        whole_year_genres_per_10{genres_index}(year_per_10,7) = whole_year_genres_per_10{genres_index}(year_per_10,7) + str2num(fullmusicdata(i,9));
        whole_year_genres_per_10{genres_index}(year_per_10,8) = whole_year_genres_per_10{genres_index}(year_per_10,8) + str2num(fullmusicdata(i,10));
        whole_year_genres_per_10{genres_index}(year_per_10,9) = whole_year_genres_per_10{genres_index}(year_per_10,9) + str2num(fullmusicdata(i,11));
        whole_year_genres_per_10{genres_index}(year_per_10,10) = whole_year_genres_per_10{genres_index}(year_per_10,10) + str2num(fullmusicdata(i,12));
        whole_year_genres_per_10{genres_index}(year_per_10,11) = whole_year_genres_per_10{genres_index}(year_per_10,11) + str2num(fullmusicdata(i,13));
        whole_year_genres_per_10{genres_index}(year_per_10,12) = whole_year_genres_per_10{genres_index}(year_per_10,12) + str2num(fullmusicdata(i,15));
        whole_year_genres_per_10{genres_index}(year_per_10,13) = whole_year_genres_per_10{genres_index}(year_per_10,13) + str2num(fullmusicdata(i,16));
        whole_year_genres_per_10{genres_index}(year_per_10,14) = whole_year_genres_per_10{genres_index}(year_per_10,14) + 1;
        
        count_year_genres{genres_index}(year_per_10) = count_year_genres{genres_index}(year_per_10) + 1;
    end   
end

for j = 1:20
    for n = 1:10
    whole_year_genres_per_10{j}(n,1:13) = whole_year_genres_per_10{j}(n,1:13)./count_year_genres{j}(n);
    end
end

feature = cell(10,1);
corr_genre_per_10 = cell(10,1);


for k = 1:10
    for kk = 1:20
        feature{k}(kk,:) = whole_year_genres_per_10{kk}(k,[1,2,3,5,8,9,11,12]);      
    end
end

for p = 1:10
    for q = 1:8
    feature_normalizing{p}(:,q) = (feature{p}(:,q) - nanmean(feature{p}(:,q))) / nanstd(feature{p}(:,q));
    end
    corr_genre_per_10{p} = corrcoef(feature_normalizing{p}');
end
 
%%
figure(1)
for v = 1:10
subplot(3,4,v)
xvalues = {'Avant-Garde','Blues','Childrens','Classical','Comedy/Spoken','Country','Easy Listening','Electronic','Folk','International','Jazz','Latin','New Age','Pop/Rock','R&B','Reggae','Religious','Stage & Screen','Unknown','Vocal'};
yvalues = {'Avant-Garde','Blues','Childrens','Classical','Comedy/Spoken','Country','Easy Listening','Electronic','Folk','International','Jazz','Latin','New Age','Pop/Rock','R&B','Reggae','Religious','Stage & Screen','Unknown','Vocal'};
h = heatmap(xvalues,yvalues,corr_genre_per_10{v},'FontSize',8);
year1 = 1911 + v * 10;
year2 = 1920 + v * 10;
title([num2str(year1),'����',num2str(year2)])
end
colormap(jet)

corr_cross = zeros(9,1);
for s = 1:9
    temp = similarity_genre_M_np(s,14,:);
    index_nan = isnan(corr_genre_per_10{s+1}(14,:));
    index_index = find(index_nan == 1);
    temp = temp(:);
    temp(index_nan) = [];
    similarity = corr_genre_per_10{s+1}(14,:);
    similarity(index_nan) = [];
    temp_corr = corrcoef(temp,similarity);
    corr_cross(s) = temp_corr(2);
end

figure(1)
plot(1930:10:2010,corr_cross,'LineStyle','-','Marker','o','Color','r','MarkerSize',2);
xlabel('Year','FontSize',18)
ylabel('Correlation','FontSize',18)
set(gca,'color','none');
save whole_year_genres_per_10 whole_year_genres_per_10
