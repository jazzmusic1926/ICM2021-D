clear;clc;close all;
feature('DefaultCharacterSet', 'UTF8');

load whole_year_genres_per_10

pop = whole_year_genres_per_10{14}(:,[1 2 3 5 8 9 11 12]);

for k = 1:8
    pop_normalizing(:,k) = zscore(pop(:,k));
end