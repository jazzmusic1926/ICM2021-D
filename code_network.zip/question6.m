load('follower_matrix_by_year_statics.mat')

authority_by_year_list_max = sort(authority_by_year_list');
authority_by_year_list_max = authority_by_year_list_max(end-4:end, :);

for flag = 1:9
    authority_by_year_list_max_one = authority_by_year_list_max(:, flag);
    authority_by_year_list_one = authority_by_year_list(flag, :);
    
    for index = 1:5
        one = authority_by_year_list_max_one(index);
        Index = find(authority_by_year_list_one == one);
        record(flag, index) = Index;
    end
    
end


for flag = 1:9
    
    for index = 1:5
        
        artist = record(flag, index);
        
        out_degree(flag, index) = odc_by_year_list(flag, artist);
        
        pagerank(flag, index) = pagerankvalues_by_year_list(flag, artist);
        
        index2id(flag, index) = artist_info_list(artist, 1);
        
    end
    
end