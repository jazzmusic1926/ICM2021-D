%% influence_data.csv
clc, clear
fileName = 'influence_data.csv';
fid = fopen(sprintf('%s\\%s', fileName), 'r', 'n', 'utf-8');
contentCell = textscan(fid, '%s', 'delimiter', '\n');
fclose(fid);
content = contentCell{1};

rowNumber = 42770;
rgxExpression = '("(.)+?",)';
dataOrganizedByCell = cell(rowNumber, 8);
for ii = 2:rowNumber + 1
    rowContent = strrep(content{ii}, ', ', '，');
    [begin, finish, strCell] = regexpi(sprintf('%s\n', sprintf('%s\n', rowContent)), rgxExpression, 'start', 'end', 'match');
    for jj = 1:length(strCell)
        temp = rowContent(begin(jj):finish(jj) - 1);
        newTemp = strrep(temp, ',', '，');
        rowContent = strrep(rowContent, temp, newTemp);
    end
    tempCell = strsplit(rowContent, ',');
    for mm = 1:8
        strrep(tempCell{mm}, '，', ',');
    end
    dataOrganizedByCell(ii - 1, :) = tempCell;
end

influencer_id = dataOrganizedByCell(:, 1);
influencer_name = dataOrganizedByCell(:, 2);
influencer_main_genre = dataOrganizedByCell(:, 3);
influencer_active_start = dataOrganizedByCell(:, 4);
follower_id = dataOrganizedByCell(:, 5);
follower_name = dataOrganizedByCell(:, 6);
follower_main_genre = dataOrganizedByCell(:, 7);
follower_active_start = dataOrganizedByCell(:, 8);

save influence_data.mat influencer_id influencer_name influencer_main_genre influencer_active_start follower_id follower_name follower_main_genre follower_active_start dataOrganizedByCell;

%% full_music_data.csv
clc, clear
dataDir = 'F:\Files\文件\数学建模\2021美赛\2021_ICM_Problem_D_Data';

fileName = 'full_music_data.csv';
fid = fopen(sprintf('%s\\%s', dataDir, fileName), 'r', 'n', 'utf-8');
contentCell = textscan(fid, '%s', 'delimiter', '\n');
fclose(fid);
content = contentCell{1}; % All data arranged in rows

rowNumber = 98340;
% Non-delimiter comma appears in such forms: comma + space or within a
% digit such as 20,000, but such
% An item with non-delimiter commas must be wrapped in ""
% Such items follow the pattern of '"[]",' or '""\n'
%
% Replace all ', ' first with '，' (Chinese)
% Use regex to locate the above pattern and replace the , with ，(Chinese)
% Seperate using ',' as the delimiter
% Replace all '，' with ','
rgxExpression = '("\[(.)+?\]"(,|\n))|("(.)+?"\n)';
dataOrganizedByCell = cell(rowNumber, 19);
    
for ii = 2:rowNumber + 1
    rowContent = content{ii};
    rowContent = strrep(rowContent, ', ', '，');
    [begin, finish, strCell] = regexpi(sprintf('%s\n', sprintf('%s\n', rowContent)), rgxExpression, 'start', 'end', 'match');
    for jj = 1:length(strCell)
        temp = rowContent(begin(jj):finish(jj) - 1);
        newTemp = strrep(temp, ',', '，');
        rowContent = strrep(rowContent, temp, newTemp);
    end
    tempCell = strsplit(rowContent, ',');
    for mm = 1:19
        strrep(tempCell{mm}, '，', ',');
    end
    dataOrganizedByCell(ii - 1, :) = tempCell;
end

artist_names = dataOrganizedByCell(:, 1);
artists_id = dataOrganizedByCell(:, 2);
danceability = dataOrganizedByCell(:, 3);
energy = dataOrganizedByCell(:, 4);
valence = dataOrganizedByCell(:, 5);
tempo = dataOrganizedByCell(:, 6);
loudness = dataOrganizedByCell(:, 7);
mode = dataOrganizedByCell(:, 8);
key = dataOrganizedByCell(:, 9);
acousticness = dataOrganizedByCell(:, 10);
instrumentalness = dataOrganizedByCell(:, 11);
liveness = dataOrganizedByCell(:, 12);
speechiness = dataOrganizedByCell(:, 13);
explicit = dataOrganizedByCell(:, 14);
duration_ms = dataOrganizedByCell(:, 15);
popularity = dataOrganizedByCell(:, 16);
year = dataOrganizedByCell(:, 17);
release_date = dataOrganizedByCell(:, 18);
song_title = dataOrganizedByCell(:, 19);

save full_music_data.mat artist_names artists_id danceability energy valence tempo loudness mode key acousticness instrumentalness liveness speechiness explicit duration_ms popularity year release_date song_title dataOrganizedByCell;



%%
clear all; clc;
load('influence_data.mat')


%% artist_info_list
follower_id = str2num(char(follower_id));
influencer_id = str2num(char(influencer_id));
artist_list = unique([follower_id, influencer_id]);

follower_active_start = str2num(char(follower_active_start));
influencer_active_start = str2num(char(influencer_active_start));
active_start_list = unique([follower_active_start, influencer_active_start]);

main_genre_list = unique([follower_main_genre(:)', influencer_main_genre(:)']);
writecell(main_genre_list, 'main_genre_list.csv')
main_genre_coding = 1:length(main_genre_list);
% main_genre_list = char(main_genre_list);
% follower_main_genre = char(follower_main_genre);
% influencer_main_genre = char(influencer_main_genre);
follower_main_genre_coding = zeros(length(follower_main_genre), 1);
influencer_main_genre_coding = zeros(length(influencer_main_genre), 1);
for ii = 1:length(main_genre_list)
    Index = strfind(follower_main_genre, main_genre_list(ii));
    Index_empty = cellfun(@isempty, Index);
    Index(Index_empty) = {0};
    Index = cell2mat(Index);
    Index = Index == 1;
    follower_main_genre_coding(Index) = ii;
    
    Index = strfind(influencer_main_genre, main_genre_list(ii));
    Index_empty = cellfun(@isempty, Index);
    Index(Index_empty) = {0};
    Index = cell2mat(Index);
    Index = Index == 1;
    influencer_main_genre_coding(Index) = ii;
end

artist_info_list = [follower_id, follower_active_start, follower_main_genre_coding;
    influencer_id, influencer_active_start, influencer_main_genre_coding];
artist_info_list = unique(artist_info_list, 'rows');


%% follower_matrix
follower_matrix = zeros(length(artist_list));
influencer_follower_list = [influencer_id, follower_id];
for ii = 1:length(influencer_follower_list)
    row = find(influencer_follower_list(ii, 1) == artist_list);
    column = find(influencer_follower_list(ii, 2) == artist_list);
    follower_matrix(row, column) = follower_matrix(row, column) + 1;
end
follower_num_list = sum(follower_matrix, 2);
save('follower_matrix.mat', 'follower_matrix')
writematrix(follower_matrix, 'follower_matrix.csv')


%% some analysis finished by python
% we could get hubs and authorits by hits


%% degree distribution
degree_in = sum(follower_matrix, 1);
degree_out = sum(follower_matrix, 2);

degree_out_artist = [degree_out, (1:length(artist_list))'];
degree_out_artist = sortrows(degree_out_artist, 1);

figure;
histogram(degree_out, 60)

% tbl = tabulate(degree_out);
% figure;
% scatter(tbl(:, 1), tbl(:, 2))
% figure;
% plot(tbl(:, 1), tbl(:, 2))
figure;
scatter(log(tbl(:, 1)), log(tbl(:, 2)))
xlabel('Artist Numbers (log scale)')
ylabel('Distribution of Out Degree (log scale)')
% figure;
% plot(log(tbl(:, 1)), log(tbl(:, 2)))

% xlim([0, 13])

sorted_degree_out = sort(degree_out, 'descend');
cumsum_degree_out = zeros(length(artist_list), 1);
cumsum = 0;
for ii = 1:length(artist_list)
    cumsum = cumsum + sorted_degree_out(ii);
    cumsum_degree_out(ii) = cumsum;
end
figure();
cumsum_degree_out_n = cumsum_degree_out / max(cumsum_degree_out);
plot(cumsum_degree_out_n)
xlim([1, 5603])
xlabel('Artists Numbers')
ylabel('Cumulative Distribution of Out Degree')
box off

% follower_num_list = sum(follower_matrix, 2);
% remember show the ROC curve!


%% 
% clustering coefficient
[C_f, aver_C, std_C] = My_Clustering_Coefficient(follower_matrix);

C_f = C_f';
C_artist = [C_f, (1:length(artist_list))'];
C_artist = sortrows(C_artist, 1);


% largest eigenvalue of the adjacency matrix and eigenvector centrality
[V_ecf, D] = eigs(follower_matrix);
largest_eigenvalue = max(max(D));
eigenvector_centrality = V_ecf(:, max(D) == largest_eigenvalue);
ec = eigenvector_centrality;
ec_artist = [eigenvector_centrality, (1:length(artist_list))'];
ec_artist = sortrows(ec_artist, 1);

% hub and authority
hub_matrix = follower_matrix * follower_matrix';
[V_hubf, D] = eigs(follower_matrix);
largest_eigenvalue = max(max(D));
hub = V_hubf(:, max(D) == largest_eigenvalue);

authority_matrix = follower_matrix' * follower_matrix;
[V_authf, D] = eigs(follower_matrix);
largest_eigenvalue = max(max(D));
authority = V_authf(:, max(D) == largest_eigenvalue);

% algebraic connectivity
S = diag(degree_out);
L = S - follower_matrix;
D_L = eig(L);
D_L = sort(D_L);
algebraic_connectivity = D_L(end-1);

% betweenness centrality


%%
C = C_f;
corr(C, degree_out, 'type', 'Spearman')
corr(degree_out, ec, 'type', 'Spearman')
corr(C, ec, 'type', 'Spearman')

corr(C, degree_in', 'type', 'Spearman')
corr(degree_in', ec, 'type', 'Spearman')
corr(degree_in', degree_out, 'type', 'Spearman')


%% follower_matrix_by_artist
%(including clustering coefficient for sub_matrix)
follower_matrix_by_artist = cell(length(artist_list), 1);
sub_artist_list = cell(length(artist_list), 1);
sub_artist_num_list = zeros(length(artist_list), 1);
sub_matrix_index_list = cell(length(artist_list), 1);
clustering_coefficient_list = zeros(length(artist_list), 1);
for ii = 1:length(artist_list)
    the_follower_index = follower_matrix(ii, :)';
    the_influencer_index = follower_matrix(:, ii);
    index_all = the_follower_index | the_influencer_index;
    index_all(ii) = 1;
    k = sum(index_all);  % degree_in + degree_out
    sub_artist_num_list(ii) = sum(index_all);
    index_all = find(index_all);
    sub_matrix_index_list{ii} = index_all;
    follower_matrix_sub = follower_matrix(index_all, index_all);
    follower_matrix_by_artist{ii} = follower_matrix_sub;
    sub_artist_list{ii} = index_all;
    
    e = sum(follower_matrix_sub, 'all') - sum(follower_matrix_sub(index_all==ii, :)) - sum(follower_matrix_sub(:, index_all==ii));
    clustering_coefficient_list(ii) = e / (k * (k -1));
end


%% top_artist_by_authority
load('hubs.mat')
hubs = hubs';

hubs_artist = [hubs, (1:length(artist_list))'];
hubs_artist = sortrows(hubs_artist, 1);

top_10 = flip(hubs_artist(end-10:end));
save('top_10_artist.mat', 'top_10')

flag = 1;
for sub_M_index = top_10
    sub_M = follower_matrix_by_artist{sub_M_index};
    degree_out_by_artist = sum(sub_M, 2);
    sub_M_name = ['sub_M_by_artist', num2str(sub_M_index)];
    sub_matrix_index_list_one = sub_matrix_index_list{sub_M_index};
    save(sub_M_name, 'sub_M', 'sub_matrix_index_list_one')
    
    index = find(sub_matrix_index_list_one == sub_M_index);
    
    % clustering coefficient
    [C, aver_C, std_C] = My_Clustering_Coefficient(sub_M);
    C_list_by_artist(flag) = C(index);
    aver_C_list_by_artist(flag) = aver_C;
    std_C_list_by_artist(flag) = std_C;
    
    % largest eigenvalue of the adjacency matrix and eigenvector centrality
    [V, D] = eigs(sub_M);
    largest_eigenvalue = max(max(real(D)));
    lambda(flag) = largest_eigenvalue;
    ec_by_artist = V(:, max(real(D)) == largest_eigenvalue);
    ec_by_artist = real(ec_by_artist);
    ec_list_by_artist(flag) = ec_by_artist(index);
    
    
    % hub and authority
    hub_matrix = sub_M * sub_M';
    [V_hubf, D] = eigs(sub_M);
    largest_eigenvalue = max(max(D));
    hub_by_artist = V_hubf(:, max(D) == largest_eigenvalue);
    hub_list_by_artist{flag} = hub_by_artist;
    
    authority_matrix = sub_M' * sub_M;
    [V_authf, D] = eigs(sub_M);
    largest_eigenvalue = max(max(D));
    authority_by_artist = V_authf(:, max(D) == largest_eigenvalue);
    authority_list_by_artist{flag} = authority_by_artist;
    
    % algebraic connectivity
    S = diag(degree_out_by_artist);
    L = S - sub_M;
    D_L = eig(L);
    D_L = sort(D_L);
    algebraic_connectivity_by_artist = D_L(2);
    algebraic_connectivity_list_by_artist(flag) = algebraic_connectivity_by_artist;
    
    flag = flag + 1;
end


%% follower_matrix_by_year
follower_matrix_by_year = cell(length(active_start_list), 1);
flag = 1;
for ii = 1:length(active_start_list)
    active_start = active_start_list(ii);
    
    follower_matrix_one = zeros(length(artist_list));
    for jj = 1:length(influencer_follower_list)
        the_follower = influencer_follower_list(jj, 2);
        the_follower_info = artist_info_list(artist_info_list(:, 1) == the_follower, :);
        if the_follower_info(2) == active_start
            row = find(influencer_follower_list(jj, 1) == artist_list);
            column = find(influencer_follower_list(jj, 2) == artist_list);
            follower_matrix_one(row, column) = follower_matrix_one(row, column) + 1;
        end
    end
    degree_out_by_year = sum(follower_matrix_one, 2);
    sub_M_name = ['sub_M_by_year', num2str(active_start)];
    save(sub_M_name, 'follower_matrix_one')
    
%     % clustering coefficient
%     [C, aver_C, std_C] = My_Clustering_Coefficient(follower_matrix_one);
%     C_list_by_year{flag} = C;
%     aver_C_list_by_year(flag) = aver_C;
%     std_C_list_by_year(flag) = std_C;
%     
%     % largest eigenvalue of the adjacency matrix and eigenvector centrality
%     [V, D] = eigs(follower_matrix_one);
%     largest_eigenvalue = max(max(D));
%     ec_by_year = V(:, max(D) == largest_eigenvalue);
%     ec_list_by_year{flag} = ec_by_year;
%     
%     % hub and authority
%     hub_matrix = follower_matrix_one * follower_matrix_one';
%     [V_hubf, D] = eigs(follower_matrix_one);
%     largest_eigenvalue = max(max(D));
%     hub_by_year = V_hubf(:, max(D) == largest_eigenvalue);
%     hub_list_by_year{flag} = hub_by_year;
%     
%     authority_matrix = follower_matrix_one' * follower_matrix_one;
%     [V_authf, D] = eigs(follower_matrix_one);
%     largest_eigenvalue = max(max(D));
%     authority_by_year = V_authf(:, max(D) == largest_eigenvalue);
%     authority_list_by_year{flag} = authority_by_year;
%     
%     % algebraic connectivity
%     S = diag(degree_out_by_year);
%     L = S - follower_matrix_one;
%     D_L = eig(L);
%     D_L = sort(D_L);
%     algebraic_connectivity_by_year = D_L(end-1);
%     algebraic_connectivity_list_by_year(flag) = algebraic_connectivity_by_year;
    
    flag = flag + 1;
    
    follower_matrix_by_year{ii} = follower_matrix_one;
end


%% genre_matrix
genre_matrix = zeros(length(main_genre_list));
genre_matrix_zeroseyes = zeros(length(main_genre_list));
for ii = 1:length(influencer_follower_list)
    row = influencer_follower_list(ii, 1) == artist_list;
    row = artist_info_list(row, 3);
    column = influencer_follower_list(ii, 2) == artist_list;
    column = artist_info_list(column, 3);
    genre_matrix(row, column) = genre_matrix(row, column) + 1;
    if row ~= column
        genre_matrix_zeroseyes(row, column) = genre_matrix_zeroseyes(row, column) + 1;
    end
end
save('genre_matrix_zeroseyes.mat', 'genre_matrix_zeroseyes')
writematrix(genre_matrix_zeroseyes, 'genre_matrix_zeroseyes.csv')

genre_matrix_zeroseyes_degree_out = sum(genre_matrix_zeroseyes, 2);
genre_matrix_zeroseyes_degree_in = sum(genre_matrix_zeroseyes, 1);


%%
% clustering coefficient
[C, aver_C, std_C] = My_Clustering_Coefficient(genre_matrix_zeroseyes);

% largest eigenvalue of the adjacency matrix and eigenvector centrality
[V_ecg, D_genre, W] = eigs(genre_matrix_zeroseyes);
largest_eigenvalue = max(max(D_genre));
eigenvector_centrality_genre = V_ecg(:, max(D_genre) == largest_eigenvalue);
ec_genre = [eigenvector_centrality_genre, (1:length(main_genre_coding))'];
ec_genre = sortrows(ec_genre, 1);

% hub and authority
hub_matrix = genre_matrix_zeroseyes * genre_matrix_zeroseyes';
[V_hubg, D] = eigs(genre_matrix_zeroseyes);
largest_eigenvalue = max(max(D));
hub = V_hubg(:, max(D) == largest_eigenvalue);

authority_matrix = genre_matrix_zeroseyes' * genre_matrix_zeroseyes;
[V_authg, D] = eigs(genre_matrix_zeroseyes);
largest_eigenvalue = max(max(D));
authority = V_authg(:, max(D) == largest_eigenvalue);

% algebraic connectivity
S = diag(sum(genre_matrix_zeroseyes, 2));
L = S - genre_matrix_zeroseyes;
D_L = eig(L);
D_L = sort(D_L);
algebraic_connectivity_genre = D_L(2);

% betweenness centrality


%% genre_matrix_by_year
genre_matrix_by_year = cell(length(active_start_list), 1);
genre_matrix_zeroseyes_by_year = cell(length(active_start_list), 1);

flag = 1;
for ii = 1:length(active_start_list)
    active_start = active_start_list(ii);
    
    genre_matrix_zeroseyes_one = zeros(length(main_genre_list));
    genre_matrix_one = zeros(length(main_genre_list));
    for jj = 1:length(influencer_follower_list)
        the_follower = influencer_follower_list(jj, 2);
        the_follower_info = artist_info_list(artist_info_list(:, 1) == the_follower, :);
        
        if the_follower_info(2) == active_start
            row = influencer_follower_list(jj, 1) == artist_list;
            row = artist_info_list(row, 3);
            column = influencer_follower_list(jj, 2) == artist_list;
            column = artist_info_list(column, 3);
            genre_matrix_one(row, column) = genre_matrix_one(row, column) + 1;
            if row ~= column
                genre_matrix_zeroseyes_one(row, column) = genre_matrix_zeroseyes_one(row, column) + 1;
            end
        end
    end
    
    degree_out_genre_by_artist = sum(genre_matrix_zeroseyes_one, 2);
    
    sub_M_name = ['sub_M_genre_by_year', num2str(active_start)];
    save(sub_M_name, 'genre_matrix_zeroseyes_one')
    
%     % clustering coefficient
%     [C, aver_C, std_C] = My_Clustering_Coefficient(genre_matrix_zeroseyes_one);
%     C_list_genre_by_year{flag} = C;
%     aver_C_list_genre_by_year(flag) = aver_C;
%     std_C_list_genre_by_year(flag) = std_C;
%     
%     % largest eigenvalue of the adjacency matrix and eigenvector centrality
%     [V, D] = eigs(genre_matrix_zeroseyes_one);
%     largest_eigenvalue = max(max(D));
%     ec_genre_by_year = V(:, max(D) == largest_eigenvalue);
%     ec_list_genre_by_artist{flag} = ec_genre_by_year;
%     
%     % hub and authority
%     hub_matrix = genre_matrix_zeroseyes_one * genre_matrix_zeroseyes_one';
%     [V_hubf, D] = eigs(genre_matrix_zeroseyes_one);
%     largest_eigenvalue = max(max(D));
%     hub_genre_by_artist = V_hubf(:, max(D) == largest_eigenvalue);
%     hub_list_genre_by_artist{flag} = hub_genre_by_artist;
%     
%     authority_matrix = genre_matrix_zeroseyes_one' * genre_matrix_zeroseyes_one;
%     [V_authf, D] = eigs(genre_matrix_zeroseyes_one);
%     largest_eigenvalue = max(max(D));
%     authority_genre_by_artist = V_authf(:, max(D) == largest_eigenvalue);
%     authority_list_genre_by_artist{flag} = authority_genre_by_artist;
%     
%     % algebraic connectivity
%     S = diag(degree_out_genre_by_artist);
%     L = S - genre_matrix_zeroseyes_one;
%     D_L = eig(L);
%     D_L = sort(D_L);
%     algebraic_connectivity_genre_by_artist = D_L(end-1);
%     algebraic_connectivity_list_genre_by_artist(flag) = algebraic_connectivity_genre_by_artist;
%     
%     genre_matrix_by_year{ii} = genre_matrix_one;
%     genre_matrix_zeroseyes_by_year{ii} = genre_matrix_zeroseyes_one;
    
    flag = flag + 1;
end

    
%%
% corrcoef([C_artist(:, 1), degree_out_artist(:, 1), ec_artist(:, 1)])
corr(C_artist(:, 1), degree_out_artist(:, 1), 'type', 'Spearman')
corr(degree_out_artist(:, 1), ec_artist(:, 1), 'type', 'Spearman')
corr(C_artist(:, 1), ec_artist(:, 1), 'type', 'Spearman')


%% follower_matrix_sub
cumsum_degree_out_per = cumsum_degree_out / cumsum_degree_out(end);
find(cumsum_degree_out_per > 0.95, 1 )
find(cumsum_degree_out_per > 0.80, 1 )
find(cumsum_degree_out_per > 0.50, 1 )


%% there are some analysis fnished in python
