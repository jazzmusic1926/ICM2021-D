# -*- coding: utf-8 -*-
"""
Created on Sun Feb  7 12:45:29 2021

@author: 薛
"""


import csv
import h5py
import networkx as nx
import numpy as np
import pandas as pd
import scipy.io as scio
import matplotlib.pyplot as plt
from scipy.stats import spearmanr
from networkx.algorithms import centrality


def cdict2ndarray(cdict):
    return(np.asarray(list(cdict.values())))


# %% follower_matrix

filename = 'follower_matrix.mat'
datas = h5py.File(filename)['follower_matrix'].value
follower_network = nx.DiGraph(datas.T)
direction = [(n, nbrdict) for n, nbrdict in follower_network.adjacency()]

dc = centrality.degree_centrality(follower_network)
idc = centrality.in_degree_centrality(follower_network)
odc = centrality.out_degree_centrality(follower_network)

ec = centrality.eigenvector_centrality(follower_network)
kc = centrality.katz_centrality(follower_network)

bc = centrality.betweenness_centrality(follower_network)
cc = centrality.closeness_centrality(follower_network)

lc = centrality.load_centrality(follower_network)

(hubs, authorities) = nx.algorithms.link_analysis.hits_alg.hits(follower_network)
pagerankvalues = nx.algorithms.link_analysis.pagerank_alg.pagerank(follower_network)

scio.savemat('authorities.mat', {'authorities': cdict2ndarray(authorities)})
scio.savemat('hubs.mat', {'hubs': cdict2ndarray(hubs)})

corrlist = []
for ii in [idc, odc, ec]:
    corrlist.append(cdict2ndarray(ii))
corrlist = np.asarray(corrlist)
corrlist = corrlist.T
corrM = spearmanr(corrlist)[0]
corrP = spearmanr(corrlist)[1]

tr = nx.transitivity(follower_network)
# aspl = nx.average_shortest_path_length(follower_network)
# di = nx.diameter(follower_network)


# %%
similarity_follower_M = nx.algorithms.similarity.simrank_similarity(follower_network) 
similarity_follower_M_np = nx.algorithms.similarity.simrank_similarity_numpy(follower_network, max_iterations=1000000)
# scio.savemat('similarity_follower_M.mat', {'similarity_follower_M': similarity_follower_M})


# %% genre_matrix_zeroseyes

filename = 'genre_matrix_zeroseyes.mat'
datas = h5py.File(filename)['genre_matrix_zeroseyes'].value
genre_network = nx.DiGraph(datas.T)
direction = [(n, nbrdict) for n, nbrdict in genre_network.adjacency()]

# dc = centrality.degree_centrality(genre_network)
# idc = centrality.in_degree_centrality(genre_network)
# odc = centrality.out_degree_centrality(genre_network)

# ec = centrality.eigenvector_centrality(genre_network)
# kc = centrality.katz_centrality_numpy(genre_network)

# bc = centrality.betweenness_centrality(genre_network)
# cc = centrality.closeness_centrality(genre_network)

# lc = centrality.load_centrality(genre_network)

(hubs, authorities) = nx.algorithms.link_analysis.hits_alg.hits(genre_network)
genre_network_for_pr = genre_network = nx.DiGraph(datas)
pagerankvalues = nx.algorithms.link_analysis.pagerank_alg.pagerank(genre_network_for_pr)

# corrlist = []
# for ii in [idc, odc, ec]:
#     corrlist.append(cdict2ndarray(ii))
# corrlist = np.asarray(corrlist)
# corrlist = corrlist.T
# corrM = spearmanr(corrlist)[0]
# corrP = spearmanr(corrlist)[1]

# tr = nx.transitivity(genre_network)
# aspl = nx.average_shortest_path_length(genre_network)
# di = nx.diameter(genre_network)


# %% follower_matrix_by_artist

artist_list = [3962, 4816, 560, 840, 3128, 1159, 372, 3289, 3527, 2522, 4617]
node_number = []
edge_number = []
dc_by_artist_list = []
idc_by_artist_list = []
odc_by_artist_list = []
ec_by_artist_list = []
kc_by_artist_list = []
bc_by_artist_list = []
cc_by_artist_list = []
lc_by_artist_list = []
hubs_by_artist_list = []
authority_by_artist_list = []
pagerankvalues_by_artist_list = []
tr_by_artist_list = []
aspl_by_artist_list = []
di_by_artist_list = []
for the_artist in artist_list:
    
    filename = 'sub_M_by_artist' + str(the_artist) + '.mat'
    datas = h5py.File(filename)['sub_M'].value
    artist = h5py.File(filename)['sub_matrix_index_list_one'].value
    
    follower_matrix_by_artist = nx.DiGraph(datas.T)
    direction = [(n, nbrdict) for n, nbrdict in follower_matrix_by_artist.adjacency()]
    index = np.squeeze(artist == the_artist)
    
    node_number.append(len(follower_matrix_by_artist.nodes))
    edge_number.append(len(follower_matrix_by_artist.edges))
    
    dc = centrality.degree_centrality(follower_matrix_by_artist)
    dc_by_artist_list.append(cdict2ndarray(dc)[index])
    idc = centrality.in_degree_centrality(follower_matrix_by_artist)
    idc_by_artist_list.append(cdict2ndarray(idc)[index])
    odc = centrality.out_degree_centrality(follower_matrix_by_artist)
    odc_by_artist_list.append(cdict2ndarray(odc)[index])
    
    ec = centrality.eigenvector_centrality(follower_matrix_by_artist, max_iter=1000000)
    ec_by_artist_list.append(cdict2ndarray(ec)[index])
    kc = centrality.katz_centrality(follower_matrix_by_artist, max_iter=1000000)
    kc_by_artist_list.append(cdict2ndarray(kc)[index])
    
    bc = centrality.betweenness_centrality(follower_matrix_by_artist)
    bc_by_artist_list.append(cdict2ndarray(bc)[index])
    cc = centrality.closeness_centrality(follower_matrix_by_artist)
    cc_by_artist_list.append(cdict2ndarray(cc)[index])
    
    lc = centrality.load_centrality(follower_matrix_by_artist)
    lc_by_artist_list.append(cdict2ndarray(lc)[index])
    
    (hubs, authorities) = nx.algorithms.link_analysis.hits_alg.hits(follower_matrix_by_artist)
    print(np.sum(cdict2ndarray(hubs)))
    print(np.sum(cdict2ndarray(hubs)))
    hubs_by_artist_list.append(cdict2ndarray(hubs)[index])
    authority_by_artist_list.append(cdict2ndarray(authorities)[index])
    follower_matrix_by_artist_fopr = nx.DiGraph(datas)
    pagerankvalues = nx.algorithms.link_analysis.pagerank_alg.pagerank(follower_matrix_by_artist)
    pagerankvalues_by_artist_list.append(cdict2ndarray(pagerankvalues)[index])
    
    corrlist = []
    for ii in [idc, odc, ec]:
        corrlist.append(cdict2ndarray(ii))
    corrlist = np.asarray(corrlist)
    corrlist = corrlist.T
    corrM = spearmanr(corrlist)[0]
    corrP = spearmanr(corrlist)[1]
    
    tr = nx.transitivity(follower_matrix_by_artist)
    tr_by_artist_list.append(tr)
    aspl = nx.average_shortest_path_length(follower_matrix_by_artist)
    aspl_by_artist_list.append(aspl)
    try:
        di = nx.diameter(follower_matrix_by_artist)
        di_by_artist_list.append(di)
    except:
        di_by_artist_list.append('None')


# %% follower_matrix_by_year

year_list = [1930, 1940, 1950, 1960, 1970, 1980, 1990, 2000, 2010]
dc_by_year_list = []
idc_by_year_list = []
odc_by_year_list = []
ec_by_year_list = []
bc_by_year_list = []
cc_by_year_list = []
lc_by_year_list = []
hubs_by_year_list = []
authority_by_year_list = []
pagerankvalues_by_year_list = []
tr_by_year_list = []
aspl_by_year_list = []
di_by_year_list = []
for the_year in year_list:
    
    filename = 'sub_M_by_year' + str(the_year) + '.mat'
    datas = h5py.File(filename)['follower_matrix_one'].value
    
    follower_matrix_by_artist = nx.DiGraph(datas.T)
    direction = [(n, nbrdict) for n, nbrdict in follower_matrix_by_artist.adjacency()]
    
    # dc = centrality.degree_centrality(follower_matrix_by_artist)
    # dc_by_year_list.append(cdict2ndarray(dc))
    # idc = centrality.in_degree_centrality(follower_matrix_by_artist)
    # idc_by_year_list.append(cdict2ndarray(idc))
    odc = centrality.out_degree_centrality(follower_matrix_by_artist)
    odc_by_year_list.append(cdict2ndarray(odc))
    
    # ec = centrality.eigenvector_centrality(follower_matrix_by_artist, max_iter=1000000)
    # ec_by_year_list.append(cdict2ndarray(ec))
    # kc = centrality.katz_centrality(follower_matrix_by_artist, max_iter=1000000)
    # bc_by_year_list.append(cdict2ndarray(kc))
    
    # bc = centrality.betweenness_centrality(follower_matrix_by_artist)
    # bc_by_year_list.append(cdict2ndarray(bc))
    # cc = centrality.closeness_centrality(follower_matrix_by_artist)
    # cc_by_year_list.append(cdict2ndarray(cc))
    
    # lc = centrality.load_centrality(follower_matrix_by_artist)
    # lc_by_year_list.append(cdict2ndarray(lc))
    
    (hubs, authorities) = nx.algorithms.link_analysis.hits_alg.hits(follower_matrix_by_artist)
    print(np.sum(cdict2ndarray(hubs)))
    print(np.sum(cdict2ndarray(hubs)))
    hubs_by_year_list.append(cdict2ndarray(hubs))
    authority_by_year_list.append(cdict2ndarray(authorities))
    follower_matrix_by_artist_for_pr = nx.DiGraph(datas)
    pagerankvalues = nx.algorithms.link_analysis.pagerank_alg.pagerank(follower_matrix_by_artist_for_pr)
    pagerankvalues_by_year_list.append(cdict2ndarray(pagerankvalues))
    
    # corrlist = []
    # for ii in [idc, odc, ec]:
    #     corrlist.append(cdict2ndarray(ii))
    # corrlist = np.asarray(corrlist)
    # corrlist = corrlist.T
    # corrM = spearmanr(corrlist)[0]
    # corrP = spearmanr(corrlist)[1]
    
    # tr = nx.transitivity(follower_matrix_by_artist)
    # tr_by_year_list.append(tr)
    # aspl = nx.average_shortest_path_length(follower_matrix_by_artist)
    # aspl_by_year_list.append(aspl)
    # try:
    #     di = nx.diameter(follower_matrix_by_artist)
    #     di_by_year_list.append(di)
    # except:
    #     di_by_year_list.append('None')

scio.savemat('follower_matrix_by_year_statics.mat', {'authority_by_year_list': np.asarray(hubs_by_year_list), 'hub_by_year_list' : np.asarray(authority_by_year_list), 'pagerankvalues_by_year_list': np.asarray(pagerankvalues_by_year_list), 'odc_by_year_list' : np.asarray(odc_by_year_list)})


# %% genre_matrix_by_year

similarity_genre_M = []
similarity_genre_M_np = []

year_list = [1930, 1940, 1950, 1960, 1970, 1980, 1990, 2000, 2010]
dc_genre_by_year_list = []
idc_genre_by_year_list = []
odc_genre_by_year_list = []
ec_genre_by_year_list = []
bc_genre_by_year_list = []
cc_genre_by_year_list = []
lc_genre_by_year_list = []
hubs_genre_by_year_list = []
authority_genre_by_year_list = []
pagerankvalues_genre_by_year_list = []
tr_genre_by_year_list = []
aspl_genre_by_year_list = []
di_genre_by_year_list = []
for the_year in year_list:
    
    filename = 'sub_M_genre_by_year' + str(the_year) + '.mat'
    datas = h5py.File(filename)['genre_matrix_zeroseyes_one'].value
    
    follower_matrix_by_artist = nx.DiGraph(datas.T)
    direction = [(n, nbrdict) for n, nbrdict in follower_matrix_by_artist.adjacency()]
    
    # dc = centrality.degree_centrality(follower_matrix_by_artist)
    # dc_genre_by_year_list.append(cdict2ndarray(dc))
    # idc = centrality.in_degree_centrality(follower_matrix_by_artist)
    # idc_genre_by_year_list.append(cdict2ndarray(idc))
    # odc = centrality.out_degree_centrality(follower_matrix_by_artist)
    # odc_genre_by_year_list.append(cdict2ndarray(odc))
    
    # ec = centrality.eigenvector_centrality(follower_matrix_by_artist, max_iter=1000000)
    # ec_genre_by_year_list.append(cdict2ndarray(ec))
    # kc = centrality.katz_centrality(follower_matrix_by_artist, max_iter=1000000)
    # bc_genre_by_year_list.append(cdict2ndarray(kc))
    
    # bc = centrality.betweenness_centrality(follower_matrix_by_artist)
    # bc_genre_by_year_list.append(cdict2ndarray(bc))
    # cc = centrality.closeness_centrality(follower_matrix_by_artist)
    # cc_genre_by_year_list.append(cdict2ndarray(cc))
    
    # lc = centrality.load_centrality(follower_matrix_by_artist)
    # lc_genre_by_year_list.append(cdict2ndarray(lc))
    
    # (hubs, authorities) = nx.algorithms.link_analysis.hits_alg.hits(follower_matrix_by_artist)
    # print(np.sum(cdict2ndarray(hubs)))
    # print(np.sum(cdict2ndarray(hubs)))
    # hubs_genre_by_year_list.append(cdict2ndarray(hubs))
    # authority_genre_by_year_list.append(cdict2ndarray(authorities))
    # pagerankvalues = nx.algorithms.link_analysis.pagerank_alg.pagerank(follower_matrix_by_artist)
    # pagerankvalues_genre_by_year_list.append(cdict2ndarray(pagerankvalues))
    
    # corrlist = []
    # for ii in [idc, odc, ec]:
    #     corrlist.append(cdict2ndarray(ii))
    # corrlist = np.asarray(corrlist)
    # corrlist = corrlist.T
    # corrM = spearmanr(corrlist)[0]
    # corrP = spearmanr(corrlist)[1]
    
    # tr = nx.transitivity(follower_matrix_by_artist)
    # tr_genre_by_year_list.append(tr)
    # aspl = nx.average_shortest_path_length(follower_matrix_by_artist)
    # aspl_genre_by_year_list.append(aspl)
    # try:
    #     di = nx.diameter(follower_matrix_by_artist)
    #     di_genre_by_year_list.append(di)
    # except:
    #     di_genre_by_year_list.append('None')
    
    similarity_genre_M.append(nx.algorithms.similarity.simrank_similarity(follower_matrix_by_artist))


# %% 
similarity_genre_M_np = np.zeros((9,20,20))
for ii in range(9):
    for jj in range(20):
        for kk in range(20):
            similarity_genre_M_np[ii, jj, kk] = similarity_genre_M[ii][jj][kk]
scio.savemat('similarity_genre_M_np.mat', {'similarity_genre_M_np': similarity_genre_M_np})

